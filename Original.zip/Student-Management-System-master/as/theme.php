<?php

include "layout/header.php";
include "page/theme/theme.php";
include "layout/footer.php";


?>