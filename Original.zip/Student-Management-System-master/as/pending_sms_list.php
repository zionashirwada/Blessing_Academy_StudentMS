<?php

include "layout/header.php";
include "page/sms/pending_sms_list.php";
include "layout/footer.php";


?>