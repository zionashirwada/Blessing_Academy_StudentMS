<?php 

include "layout/header.php";
include "page/batch/batch_list.php";
include "layout/footer.php";


?>