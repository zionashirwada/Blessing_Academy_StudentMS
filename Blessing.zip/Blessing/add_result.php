<?php

include 'layout/header.php';
include 'page/result/add_result.php';
include 'layout/footer.php';

?>