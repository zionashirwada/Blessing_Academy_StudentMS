<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-7">
                <?php include "left_payment_option.php"; ?>
            </div>
            <div class="col-md-5">
                <?php include "right_payment_option.php"; ?>
            </div>
        </div>
    </div> 
</div>