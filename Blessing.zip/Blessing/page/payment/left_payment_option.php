<div class="left_class">
	<input type="number" name="" placeholder="Enter Student ID">
</div>
<style type="text/css">
	.left_class{
		border: 4px solid var(--bg-color);
		height: 440px;
	}
</style>