
  <div class="row">
      <div class="col-xs-12 col-sm-12">
          <form  action="subject_action.php" autocomplete="off" method="POST">

  <div class="form-group">
    <label class="control-label" for="inputName"><b>Teacher Name</b></label>
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-exclamation-sign"></i></span>
        <input class="form-control" data-error="Please enter name field." id="date" value="" placeholder="Enter Teacher Name"  type="text" name="name"  required="" />
    </div>
    <div id="err_product_date" class="error"></div>
  </div>

  <div class="form-group">
    <label class="control-label" for="inputName"><b>Teacher Code</b></label>
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-exclamation-sign"></i></span>
        <input class="form-control" data-error="Please enter name field." id="date" value="" placeholder="Enter Teacher Code"  type="text" name="code"  required="" />
    </div>
    <div id="err_product_date" class="error"></div>
  </div>
          <button class="btn btn-lg btn-primary btn-block" name="insert" type="submit"><span class="glyphicon glyphicon-floppy-save"></span> Save</button>
        </form>
      </div>
</div>
