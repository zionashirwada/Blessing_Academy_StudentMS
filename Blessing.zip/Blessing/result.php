<?php



include "layout/header.php";
include "page/result/public_result.php";
include "layout/footer.php";


?>

 <script language="JavaScript" src="page/result/result.js" type="text/javascript"></script>